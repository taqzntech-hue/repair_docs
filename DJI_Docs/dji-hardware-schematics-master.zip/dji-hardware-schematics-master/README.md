# dji-hardware-schematics
Community made schematics for the DJI drones and devices.

The repository stored KiCad projects with schematocs and PCBs of various parts of DJI hardware.
These projects are community made, and very likely have errors. They come with no warranty.

If you see an error in a schematic, or want to contribute your own - you are free to do it. Your contribution will be verified and accepted into this repository.
